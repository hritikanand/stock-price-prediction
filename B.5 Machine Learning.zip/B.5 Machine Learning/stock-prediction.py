# File: stock_prediction.py
# Authors: Bao Vo and Cheong Koo
# Date: 14/07/2021(v1); 19/07/2021 (v2); 02/07/2024 (v3)
# Code modified from:
# Title: Predicting Stock Prices with Python
# By: NeuralNine

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, LSTM, GRU, SimpleRNN

#------------------------------------------------------------------------------
# Load and Process Data Function
#------------------------------------------------------------------------------
def load_and_process_data(start_date, end_date, company, features, split_method="ratio", test_size=0.2,
                          save_data=False, load_data=False, na_method='ffill'):
    data = yf.download(company, start=start_date, end=end_date)
    
    if na_method == 'ffill':
        data.fillna(method='ffill', inplace=True)
    elif na_method == 'bfill':
        data.fillna(method='bfill', inplace=True)
    elif na_method == 'drop':
        data.dropna(inplace=True)
    elif na_method == 'zero':
        data.fillna(0, inplace=True)

    scalers = {}
    for feature in features:
        scaler = MinMaxScaler(feature_range=(0, 1))
        data[feature] = scaler.fit_transform(data[feature].values.reshape(-1, 1))
        scalers[feature] = scaler

    split_index = int(len(data) * (1 - test_size))
    train_data = data[:split_index]
    test_data = data[split_index:]

    if save_data:
        data.to_csv(f'{company}_data.csv')

    return train_data, test_data, scalers, data

#------------------------------------------------------------------------------
# Configuration
#------------------------------------------------------------------------------
COMPANY = 'CBA.AX'
START_DATE = '2020-01-01'
END_DATE = '2024-07-01'
FEATURES = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
PREDICTION_DAYS = 60
OUTPUT_STEPS = 5  # Number of days to predict into the future for multistep prediction

# Load and process the data
train_data, test_data, scalers, full_data = load_and_process_data(
    start_date=START_DATE,
    end_date=END_DATE,
    company=COMPANY,
    features=FEATURES,
    split_method="ratio",
    test_size=0.2
)

#------------------------------------------------------------------------------
# Prepare Data for Model
#------------------------------------------------------------------------------
def prepare_multivariate_data(data, prediction_days, features, output_steps=1):
    x, y = [], []
    for i in range(prediction_days, len(data) - output_steps + 1):
        x.append(data[features].iloc[i-prediction_days:i].values)
        y.append(data['Close'].iloc[i:i+output_steps].values)  # Predict multiple steps ahead
    return np.array(x), np.array(y)

x_train, y_train = prepare_multivariate_data(train_data, PREDICTION_DAYS, FEATURES, OUTPUT_STEPS)
x_test, y_test = prepare_multivariate_data(test_data, PREDICTION_DAYS, FEATURES, OUTPUT_STEPS)

# Define input shape
input_shape = (x_train.shape[1], x_train.shape[2])  # (Prediction days, number of features)

#------------------------------------------------------------------------------
# Build a Deep Learning Model for Multivariate, Multistep Prediction
#------------------------------------------------------------------------------
def build_multivariate_multistep_model(input_shape, num_layers=3, layer_type='LSTM', layer_sizes=[50, 50, 50], 
                                       dropout_rate=0.2, output_steps=1):
    model = Sequential()
    for i in range(num_layers):
        if i == 0:
            if layer_type == 'LSTM':
                model.add(LSTM(units=layer_sizes[i], return_sequences=True, input_shape=input_shape))
            elif layer_type == 'GRU':
                model.add(GRU(units=layer_sizes[i], return_sequences=True, input_shape=input_shape))
            elif layer_type == 'RNN':
                model.add(SimpleRNN(units=layer_sizes[i], return_sequences=True, input_shape=input_shape))
        else:
            if layer_type == 'LSTM':
                model.add(LSTM(units=layer_sizes[i], return_sequences=(i < num_layers - 1)))
            elif layer_type == 'GRU':
                model.add(GRU(units=layer_sizes[i], return_sequences=(i < num_layers - 1)))
            elif layer_type == 'RNN':
                model.add(SimpleRNN(units=layer_sizes[i], return_sequences=(i < num_layers - 1)))
        model.add(Dropout(dropout_rate))
    
    model.add(Dense(units=output_steps))  # Adjust the output layer for multiple steps
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

#------------------------------------------------------------------------------
# Train and Predict Multistep using Multivariate Model
#------------------------------------------------------------------------------
model_multistep = build_multivariate_multistep_model(input_shape, num_layers=3, layer_type='LSTM', output_steps=OUTPUT_STEPS)
model_multistep.fit(x_train, y_train, epochs=25, batch_size=32)

# Predict for the next OUTPUT_STEPS days
predicted_prices_multistep = model_multistep.predict(x_test)
real_prices_multistep = y_test

# Inverse scale the results
scaler_close = scalers["Close"]
predicted_prices_multistep = scaler_close.inverse_transform(predicted_prices_multistep)
real_prices_multistep = scaler_close.inverse_transform(real_prices_multistep)

# Plot the results
for step in range(OUTPUT_STEPS):
    plt.plot(real_prices_multistep[:, step], label=f'Actual Price (Day +{step+1})')
    plt.plot(predicted_prices_multistep[:, step], label=f'Predicted Price (Day +{step+1})')
    plt.title(f'{COMPANY} Multistep Prediction (Day +{step+1})')
    plt.xlabel("Time")
    plt.ylabel("Price")
    plt.legend()
    plt.show()
