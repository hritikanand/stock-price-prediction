import requests
from textblob import TextBlob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, LSTM
import pandas_datareader.data as web
import yfinance as yf

# NewsAPI key
NEWS_API_KEY = '55c694a0dd8f4b2e9ffd7c97b46102f4'

# Step 1: Fetch news articles related to the company (Commonwealth Bank of Australia)
def fetch_news(company, api_key):
    url = f'https://newsapi.org/v2/everything?q={company}&sortBy=publishedAt&apiKey={api_key}'
    response = requests.get(url)
    news_data = response.json()
    return news_data

# Step 2: Analyze sentiment of fetched news articles
def analyze_sentiment(articles):
    sentiment_scores = []
    for article in articles:
        description = article['description']
        if description:
            blob = TextBlob(description)
            sentiment_scores.append(blob.sentiment.polarity)  # Polarity score (-1 to 1)
    
    if sentiment_scores:
        average_sentiment = sum(sentiment_scores) / len(sentiment_scores)
    else:
        average_sentiment = 0
    
    return average_sentiment

# Fetch and analyze news articles related to Commonwealth Bank
news_data = fetch_news('Commonwealth Bank of Australia', NEWS_API_KEY)
articles = news_data.get('articles', [])
news_sentiment_score = analyze_sentiment(articles)
print(f"Average Sentiment Score for Commonwealth Bank news: {news_sentiment_score}")

# Step 3: Fetch stock data and macroeconomic data (Interest Rates, Inflation)
# Fetch stock data from Yahoo Finance
stock_data = yf.download('CBA.AX', start='2020-06-01', end='2024-01-01')

# Fetch macroeconomic data from FRED (Interest Rates and Inflation)
interest_rates = web.DataReader('FEDFUNDS', 'fred', '2020-06-01', '2024-01-01')
inflation = web.DataReader('CPIAUCSL', 'fred', '2020-06-01', '2024-01-01')

# Merge stock data with macroeconomic data
combined_data = pd.merge(stock_data, interest_rates, how='left', left_index=True, right_index=True)
combined_data = pd.merge(combined_data, inflation, how='left', left_index=True, right_index=True)
combined_data.rename(columns={'FEDFUNDS': 'Interest_Rate', 'CPIAUCSL': 'Inflation'}, inplace=True)
combined_data.ffill(inplace=True)

# Step 4: Feature Engineering (Lagged Features, Moving Averages, News Sentiment)
combined_data['Close_1D_Lag'] = combined_data['Close'].shift(1)
combined_data['Close_7D_Lag'] = combined_data['Close'].shift(7)
combined_data['Close_7D_MA'] = combined_data['Close'].rolling(window=7).mean()
combined_data['Close_30D_MA'] = combined_data['Close'].rolling(window=30).mean()
combined_data['Rolling_Volatility'] = combined_data['Close'].rolling(window=30).std()

# Add the news sentiment score as a feature
combined_data['News_Sentiment'] = news_sentiment_score

# Drop rows with NaN values created by lagged features and moving averages
combined_data.dropna(inplace=True)

# Step 5: Train-Test Split
features = ['Open', 'High', 'Low', 'Volume', 'Interest_Rate', 'Inflation', 
            'Rolling_Volatility', 'Close_1D_Lag', 'Close_7D_Lag', 
            'Close_7D_MA', 'Close_30D_MA', 'News_Sentiment']

target = 'Close'
X = combined_data[features]
y = combined_data[target]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 6: Linear Regression Model
linear_reg_model = LinearRegression()
linear_reg_model.fit(X_train, y_train)
y_pred_linear = linear_reg_model.predict(X_test)

# Step 7: Hyperparameter Tuning for Random Forest using GridSearchCV
rf_model = RandomForestRegressor(random_state=42)
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [5, 10, 20],
    'min_samples_split': [2, 5, 10]
}
grid_search = GridSearchCV(rf_model, param_grid, cv=5, scoring='neg_mean_squared_error')
grid_search.fit(X_train, y_train)

# Best Random Forest model
best_rf_model = grid_search.best_estimator_
y_pred_rf = best_rf_model.predict(X_test)

# Step 8: LSTM Model for Time-Series Prediction
X_lstm_train = X_train.values.reshape(X_train.shape[0], X_train.shape[1], 1)
X_lstm_test = X_test.values.reshape(X_test.shape[0], X_test.shape[1], 1)

lstm_model = Sequential()
lstm_model.add(LSTM(units=50, return_sequences=True, input_shape=(X_lstm_train.shape[1], 1)))
lstm_model.add(Dropout(0.2))
lstm_model.add(LSTM(units=50))
lstm_model.add(Dropout(0.2))
lstm_model.add(Dense(units=1))

lstm_model.compile(optimizer='adam', loss='mean_squared_error')
lstm_model.fit(X_lstm_train, y_train, epochs=25, batch_size=32)

y_pred_lstm = lstm_model.predict(X_lstm_test)

# Step 9: Ensemble Predictions (Combining Linear, RF, and LSTM)
def ensemble_predictions(models, X):
    predictions = [model.predict(X) for model in models]
    return np.mean(predictions, axis=0)

models = [linear_reg_model, best_rf_model]
ensemble_preds = ensemble_predictions(models, X_test)

# Step 10: Visualizations

# Correlation matrix heatmap
correlation_matrix = combined_data[['Close', 'Interest_Rate', 'Inflation', 'Rolling_Volatility', 'News_Sentiment']].corr()

plt.figure(figsize=(12, 10))  # Further increase figure size for more space
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', vmin=-1, vmax=1, cbar=True, 
            annot_kws={"size": 12}, linewidths=0.5)  # Annotation size control

# Improve x-axis and y-axis label appearance
plt.title('Correlation Between Stock Price, Inflation, Interest Rate, Volatility, and News Sentiment', size=14)
plt.xticks(rotation=45, ha='right', fontsize=12)  # Increase font size and rotate x-axis labels
plt.yticks(fontsize=12)

plt.tight_layout(pad=2.0)  # Add padding for better spacing between elements
plt.show()

# Actual vs Predicted Stock Prices for each model
plt.figure(figsize=(14, 10))

# Actual Prices
plt.subplot(4, 1, 1)
plt.plot(y_test.values, label='Actual Prices', color='blue')
plt.title('Actual Stock Prices')

# Linear Regression Predictions
plt.subplot(4, 1, 2)
plt.plot(y_pred_linear, label='Linear Regression Predicted', color='green')
plt.title('Linear Regression Predicted Prices')

# Random Forest Predictions
plt.subplot(4, 1, 3)
plt.plot(y_pred_rf, label='Random Forest Predicted', color='orange')
plt.title('Random Forest Predicted Prices')

# LSTM Predictions
plt.subplot(4, 1, 4)
plt.plot(y_pred_lstm, label='LSTM Predicted', color='red')
plt.title('LSTM Predicted Prices')

plt.tight_layout()
plt.show()

# Combined Ensemble Prediction Plot
plt.figure(figsize=(14, 7))
plt.plot(y_test.values, label='Actual Prices', color='blue')
plt.plot(ensemble_preds, label='Ensemble Predicted', color='purple')
plt.title('Ensemble Model Predicted Prices')
plt.xlabel('Time')
plt.ylabel('Price')
plt.legend()
plt.show()

# Step 11: Final Evaluation
mse_ensemble = mean_squared_error(y_test, ensemble_preds)
print(f'Ensemble Model MSE: {mse_ensemble}')

# Evaluate all models' MSE
mse_linear = mean_squared_error(y_test, y_pred_linear)
mse_rf = mean_squared_error(y_test, y_pred_rf)
mse_lstm = mean_squared_error(y_test, y_pred_lstm)

print(f'Linear Regression MSE: {mse_linear}')
print(f'Random Forest MSE: {mse_rf}')
print(f'LSTM Model MSE: {mse_lstm}')
