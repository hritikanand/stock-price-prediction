# File: stock_prediction.py
# Authors: Bao Vo and Cheong Koo
# Date: 14/07/2021(v1); 19/07/2021 (v2); 02/07/2024 (v3)
# Code modified from:
# Title: Predicting Stock Prices with Python
# By: NeuralNine

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import yfinance as yf
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, LSTM, GRU, SimpleRNN
from statsmodels.tsa.arima.model import ARIMA
import warnings

#------------------------------------------------------------------------------
# Load and Process Data Function
#------------------------------------------------------------------------------
def load_and_process_data(start_date, end_date, company, features, split_method="ratio", test_size=0.2,
                          save_data=False, load_data=False, na_method='ffill'):
    data = yf.download(company, start=start_date, end=end_date)

    # Ensure date index has a frequency (daily in this case)
    data.index = pd.date_range(start=start_date, periods=len(data), freq='D')

    # Handle NaN values
    if na_method == 'ffill':
        data.fillna(method='ffill', inplace=True)
    elif na_method == 'bfill':
        data.fillna(method='bfill', inplace=True)
    elif na_method == 'drop':
        data.dropna(inplace=True)
    elif na_method == 'zero':
        data.fillna(0, inplace=True)

    # Scale the selected features
    scalers = {}
    for feature in features:
        scaler = MinMaxScaler(feature_range=(0, 1))
        data[feature] = scaler.fit_transform(data[feature].values.reshape(-1, 1))
        scalers[feature] = scaler

    split_index = int(len(data) * (1 - test_size))
    train_data = data[:split_index]
    test_data = data[split_index:]

    if save_data:
        data.to_csv(f'{company}_data.csv')

    return train_data, test_data, scalers, data

#------------------------------------------------------------------------------
# Configuration
#------------------------------------------------------------------------------
COMPANY = 'CBA.AX'
START_DATE = '2020-01-01'
END_DATE = '2024-07-01'
FEATURES = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
PREDICTION_DAYS = 60

# Load and process the data
train_data, test_data, scalers, full_data = load_and_process_data(
    start_date=START_DATE,
    end_date=END_DATE,
    company=COMPANY,
    features=FEATURES,
    split_method="ratio",
    test_size=0.2
)

#------------------------------------------------------------------------------
# Prepare Data for Model
#------------------------------------------------------------------------------
def prepare_data(data, prediction_days, features):
    x, y = [], []
    for i in range(prediction_days, len(data)):
        x.append(data[features].iloc[i-prediction_days:i].values)
        y.append(data['Close'].iloc[i])
    return np.array(x), np.array(y)

x_train, y_train = prepare_data(train_data, PREDICTION_DAYS, FEATURES)
x_test, y_test = prepare_data(test_data, PREDICTION_DAYS, FEATURES)

# Define input shape
input_shape = (x_train.shape[1], x_train.shape[2])  # (Prediction days, number of features)

#------------------------------------------------------------------------------
# Build Deep Learning Model (LSTM)
#------------------------------------------------------------------------------
def build_lstm_model(input_shape):
    model = Sequential()
    model.add(LSTM(units=50, return_sequences=True, input_shape=input_shape))
    model.add(Dropout(0.2))
    model.add(LSTM(units=50))
    model.add(Dropout(0.2))
    model.add(Dense(units=1))
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

# Train LSTM model
lstm_model = build_lstm_model(input_shape)
lstm_model.fit(x_train, y_train, epochs=25, batch_size=32)

# LSTM predictions
lstm_preds = lstm_model.predict(x_test)
scaler_close = scalers['Close']
lstm_preds = scaler_close.inverse_transform(lstm_preds)
y_test_inverse = scaler_close.inverse_transform(y_test.reshape(-1, 1))

#------------------------------------------------------------------------------
# ARIMA Model
#------------------------------------------------------------------------------
def build_arima_model(train_data):
    arima_model = ARIMA(train_data['Close'], order=(5, 1, 0))  # can adjust ARIMA order
    arima_model_fit = arima_model.fit()
    return arima_model_fit

# Train ARIMA model
arima_model_fit = build_arima_model(train_data)

# ARIMA predictions
arima_preds = arima_model_fit.forecast(steps=len(test_data))

# Convert ARIMA predictions from Series to numpy array
arima_preds = np.array(arima_preds).reshape(-1, 1)

# Now you can inverse transform the ARIMA predictions
arima_preds = scaler_close.inverse_transform(arima_preds)

#------------------------------------------------------------------------------
# Align the predictions: Truncate the longer array
#------------------------------------------------------------------------------
min_length = min(len(lstm_preds), len(arima_preds))
lstm_preds = lstm_preds[:min_length]
arima_preds = arima_preds[:min_length]
y_test_inverse = y_test_inverse[:min_length]

#------------------------------------------------------------------------------
# Ensemble Model: Combine LSTM and ARIMA Predictions
#------------------------------------------------------------------------------
def ensemble_predictions(lstm_preds, arima_preds, weight_lstm=0.7, weight_arima=0.3):
    ensemble_preds = (weight_lstm * lstm_preds) + (weight_arima * arima_preds)
    return ensemble_preds

# Combine LSTM and ARIMA predictions
ensemble_preds = ensemble_predictions(lstm_preds, arima_preds)

#------------------------------------------------------------------------------
# Plot and Compare Results
#------------------------------------------------------------------------------
plt.plot(y_test_inverse, label='Actual Price', color='blue')
plt.plot(ensemble_preds, label='Ensemble Predicted Price', color='orange')
plt.title(f'{COMPANY} Ensemble Prediction')
plt.xlabel('Time')
plt.ylabel('Price')
plt.legend()
plt.show()

# Calculate MSE for Ensemble
mse_ensemble = mean_squared_error(y_test_inverse, ensemble_preds)
print(f'Ensemble Model MSE: {mse_ensemble}')
