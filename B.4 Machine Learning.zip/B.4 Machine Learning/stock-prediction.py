# File: stock_prediction.py
# Authors: Bao Vo and Cheong Koo
# Date: 14/07/2021(v1); 19/07/2021 (v2); 02/07/2024 (v3)
# Code modified from:
# Title: Predicting Stock Prices with Python
# YouTube link: https://www.youtube.com/watch?v=PuZY9q-aKLw
# By: NeuralNine
# Need to install the following (best in a virtual env):
# pip install numpy
# pip install matplotlib
# pip install pandas
# pip install tensorflow
# pip install scikit-learn
# pip install yfinance
# pip install mplfinance
# pip install plotly

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import yfinance as yf
import mplfinance as mpf  # Required for candlestick chart visualization
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, LSTM, GRU, SimpleRNN
import plotly.graph_objs as go
import plotly.offline as pyo

#------------------------------------------------------------------------------
# Load and Process Data Function
#------------------------------------------------------------------------------
def load_and_process_data(start_date, end_date, company, features, split_method="ratio", test_size=0.2,
                          train_start=None, train_end=None, test_start=None, test_end=None,
                          save_data=False, load_data=False, na_method='ffill'):
    # Load data from Yahoo Finance
    data = yf.download(company, start=start_date, end=end_date)

    # Handle NaN values
    if na_method == 'ffill':
        data.fillna(method='ffill', inplace=True)
    elif na_method == 'bfill':
        data.fillna(method='bfill', inplace=True)
    elif na_method == 'drop':
        data.dropna(inplace=True)
    elif na_method == 'zero':
        data.fillna(0, inplace=True)

    # Scale the selected features
    scalers = {}
    for feature in features:
        scaler = MinMaxScaler(feature_range=(0, 1))
        data[feature] = scaler.fit_transform(data[feature].values.reshape(-1, 1))
        scalers[feature] = scaler

    # Split the data into train and test sets
    if split_method == "ratio":
        split_index = int(len(data) * (1 - test_size))
        train_data = data[:split_index]
        test_data = data[split_index:]
    elif split_method == "date":
        train_data = data.loc[train_start:train_end]
        test_data = data.loc[test_start:test_end]

    # Save data 
    if save_data:
        data.to_csv(f'{company}_data.csv')

    return train_data, test_data, scalers, data

#------------------------------------------------------------------------------
# Configuration
#------------------------------------------------------------------------------
COMPANY = 'CBA.AX'
START_DATE = '2020-01-01'
END_DATE = '2024-07-01'
TRAIN_START = '2020-01-01'
TRAIN_END = '2023-08-01'
TEST_START = '2023-08-02'
TEST_END = '2024-07-01'
FEATURES = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
PREDICTION_DAYS = 60

# Load and process the data
train_data, test_data, scalers, full_data = load_and_process_data(
    start_date=START_DATE,
    end_date=END_DATE,
    company=COMPANY,
    features=FEATURES,
    split_method="date",
    train_start=TRAIN_START,
    train_end=TRAIN_END,
    test_start=TEST_START,
    test_end=TEST_END,
    save_data=True,
    load_data=False,
    na_method='ffill'
)

#------------------------------------------------------------------------------
# Prepare Data for Model
#------------------------------------------------------------------------------
def prepare_data(data, prediction_days, features):
    x, y = [], []
    for i in range(prediction_days, len(data)):
        x.append(data[features].iloc[i-prediction_days:i].values)
        y.append(data[features].iloc[i][features.index("Close")])
    x, y = np.array(x), np.array(y)
    return x, y

x_train, y_train = prepare_data(train_data, PREDICTION_DAYS, FEATURES)
x_test, y_test = prepare_data(test_data, PREDICTION_DAYS, FEATURES)

#------------------------------------------------------------------------------
# Build a Deep Learning Model Function
#------------------------------------------------------------------------------
def build_dl_model(input_shape, num_layers=3, layer_type='LSTM', layer_sizes=[50, 50, 50], dropout_rate=0.2):
    model = Sequential()
    for i in range(num_layers):
        if i == 0:
            if layer_type == 'LSTM':
                model.add(LSTM(units=layer_sizes[i], return_sequences=True, input_shape=input_shape))
            elif layer_type == 'GRU':
                model.add(GRU(units=layer_sizes[i], return_sequences=True, input_shape=input_shape))
            elif layer_type == 'RNN':
                model.add(SimpleRNN(units=layer_sizes[i], return_sequences=True, input_shape=input_shape))
        else:
            if layer_type == 'LSTM':
                model.add(LSTM(units=layer_sizes[i], return_sequences=(i < num_layers - 1)))
            elif layer_type == 'GRU':
                model.add(GRU(units=layer_sizes[i], return_sequences=(i < num_layers - 1)))
            elif layer_type == 'RNN':
                model.add(SimpleRNN(units=layer_sizes[i], return_sequences=(i < num_layers - 1)))
        model.add(Dropout(dropout_rate))
    model.add(Dense(units=1))
    model.compile(optimizer='adam', loss='mean_squared_error')
    return model

#------------------------------------------------------------------------------
# Build LSTM Model
#------------------------------------------------------------------------------
input_shape = (x_train.shape[1], x_train.shape[2])
model_lstm = build_dl_model(input_shape, num_layers=3, layer_type='LSTM')
model_lstm.fit(x_train, y_train, epochs=25, batch_size=32)

# Predict the next day's price using the LSTM model
real_data = [test_data[FEATURES].iloc[-PREDICTION_DAYS:].values]
real_data = np.array(real_data)
prediction_lstm = model_lstm.predict(real_data)
prediction_lstm = scalers["Close"].inverse_transform(prediction_lstm)
print(f"Prediction for the next day: {prediction_lstm[0][0]}")

# Function to experiment with different DL networks and configurations
def experiment_with_models(x_train, y_train, x_test, y_test, layers_configurations, epochs=25, batch_size=32):
    results = {}
    for config in layers_configurations:
        model_type = config.get('layer_type', 'LSTM')
        num_layers = config.get('num_layers', 3)
        layer_sizes = config.get('layer_sizes', [50] * num_layers)
        dropout_rate = config.get('dropout_rate', 0.2)

        model = build_dl_model(input_shape, num_layers=num_layers, layer_type=model_type, layer_sizes=layer_sizes, dropout_rate=dropout_rate)
        model.fit(x_train, y_train, epochs=epochs, batch_size=batch_size)

        predicted_prices = model.predict(x_test)
        predicted_prices = scalers["Close"].inverse_transform(predicted_prices)
        real_prices = scalers["Close"].inverse_transform(y_test.reshape(-1, 1))

        mse = np.mean((predicted_prices - real_prices) ** 2)
        results[model_type] = {'MSE': mse, 'Predicted Prices': predicted_prices, 'Real Prices': real_prices}

    return results

# Experiment with different DL models and configurations
layers_configurations = [
    {'layer_type': 'LSTM', 'num_layers': 3, 'layer_sizes': [50, 50, 50], 'dropout_rate': 0.2},
    {'layer_type': 'GRU', 'num_layers': 3, 'layer_sizes': [50, 50, 50], 'dropout_rate': 0.2},
    {'layer_type': 'RNN', 'num_layers': 3, 'layer_sizes': [50, 50, 50], 'dropout_rate': 0.2},
]

experiment_results = experiment_with_models(x_train, y_train, x_test, y_test, layers_configurations)

# Print out the results for each model
for model_type, result in experiment_results.items():
    print(f"Model: {model_type}, MSE: {result['MSE']}")
    plt.plot(result['Real Prices'], color="black", label="Actual Prices")
    plt.plot(result['Predicted Prices'], label=f"Predicted Prices ({model_type})")
    plt.title(f"{COMPANY} Share Price Prediction using {model_type}")
    plt.xlabel("Time")
    plt.ylabel(f"{COMPANY} Share Price")
    plt.legend()
    plt.show()


#------------------------------------------------------------------------------
# Predict Next Day with LSTM Model
#------------------------------------------------------------------------------
real_data = [test_data[FEATURES].iloc[-PREDICTION_DAYS:].values]
real_data = np.array(real_data)
prediction_lstm = model_lstm.predict(real_data)
prediction_lstm = scalers["Close"].inverse_transform(prediction_lstm)
print(f"Prediction for the next day using LSTM: {prediction_lstm[0][0]}")

# Experiment with GRU Model
model_gru = build_dl_model(input_shape, num_layers=3, layer_type='GRU')
model_gru.fit(x_train, y_train, epochs=25, batch_size=32)

# Predict the next day's price using the GRU model
prediction_gru = model_gru.predict(real_data)
prediction_gru = scalers["Close"].inverse_transform(prediction_gru)
print(f"Prediction for the next day using GRU: {prediction_gru[0][0]}")

# Experiment with RNN Model
model_rnn = build_dl_model(input_shape, num_layers=3, layer_type='RNN')
model_rnn.fit(x_train, y_train, epochs=25, batch_size=32)

# Predict the next day's price using the RNN model
prediction_rnn = model_rnn.predict(real_data)
prediction_rnn = scalers["Close"].inverse_transform(prediction_rnn)
print(f"Prediction for the next day using RNN: {prediction_rnn[0][0]}")
