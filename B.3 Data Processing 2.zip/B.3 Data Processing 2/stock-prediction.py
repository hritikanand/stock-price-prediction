# File: stock_prediction.py
# Authors: Bao Vo and Cheong Koo
# Date: 14/07/2021(v1); 19/07/2021 (v2); 02/07/2024 (v3)
# Code modified from:
# Title: Predicting Stock Prices with Python
# YouTube link: https://www.youtube.com/watch?v=PuZY9q-aKLw
# By: NeuralNine
# Need to install the following (best in a virtual env):
# pip install numpy
# pip install matplotlib
# pip install pandas
# pip install tensorflow
# pip install scikit-learn
# pip install yfinance
# pip install mplfinance
# pip install plotly

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import yfinance as yf
import mplfinance as mpf  # Required for candlestick chart visualization
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout, LSTM
import plotly.graph_objs as go
import plotly.offline as pyo

#------------------------------------------------------------------------------
# Load and Process Data Function
## This function will allow you to specify the start date and the end date for the whole dataset as inputs.
## It will handle NaN values, allow different methods to split the data into train/test,
## optionally save the data, and scale feature columns, storing the scalers for future access.
#------------------------------------------------------------------------------
def load_and_process_data(start_date, end_date, company, features, split_method="ratio", test_size=0.2,
                          train_start=None, train_end=None, test_start=None, test_end=None,
                          save_data=False, load_data=False, na_method='ffill'):
    # Load data from Yahoo Finance
    data = yf.download(company, start=start_date, end=end_date)

    # Handle NaN values
    if na_method == 'ffill':
        data.fillna(method='ffill', inplace=True)
    elif na_method == 'bfill':
        data.fillna(method='bfill', inplace=True)
    elif na_method == 'drop':
        data.dropna(inplace=True)
    elif na_method == 'zero':
        data.fillna(0, inplace=True)

    # Scale the selected features
    scalers = {}
    for feature in features:
        scaler = MinMaxScaler(feature_range=(0, 1))
        data[feature] = scaler.fit_transform(data[feature].values.reshape(-1, 1))
        scalers[feature] = scaler

    # Split the data into train and test sets
    if split_method == "ratio":
        split_index = int(len(data) * (1 - test_size))
        train_data = data[:split_index]
        test_data = data[split_index:]
    elif split_method == "date":
        train_data = data.loc[train_start:train_end]
        test_data = data.loc[test_start:test_end]

    # Save data 
    if save_data:
        data.to_csv(f'{company}_data.csv')

    return train_data, test_data, scalers, data

#------------------------------------------------------------------------------
# Configuration
#------------------------------------------------------------------------------
COMPANY = 'CBA.AX'
START_DATE = '2020-01-01'
END_DATE = '2024-07-01'
TRAIN_START = '2020-01-01'
TRAIN_END = '2023-08-01'
TEST_START = '2023-08-02'
TEST_END = '2024-07-01'
FEATURES = ["Open", "High", "Low", "Close", "Adj Close", "Volume"]
PREDICTION_DAYS = 60

# Load and process the data
train_data, test_data, scalers, full_data = load_and_process_data(
    start_date=START_DATE,
    end_date=END_DATE,
    company=COMPANY,
    features=FEATURES,
    split_method="date",
    train_start=TRAIN_START,
    train_end=TRAIN_END,
    test_start=TEST_START,
    test_end=TEST_END,
    save_data=True,
    load_data=False,
    na_method='ffill'
)

#------------------------------------------------------------------------------
# Prepare Data for Model
#------------------------------------------------------------------------------
def prepare_data(data, prediction_days, features):
    x, y = [], []
    for i in range(prediction_days, len(data)):
        x.append(data[features].iloc[i-prediction_days:i].values)
        y.append(data[features].iloc[i][features.index("Close")])
    x, y = np.array(x), np.array(y)
    return x, y

x_train, y_train = prepare_data(train_data, PREDICTION_DAYS, FEATURES)
x_test, y_test = prepare_data(test_data, PREDICTION_DAYS, FEATURES)

#------------------------------------------------------------------------------
# Build and Train the Model
#------------------------------------------------------------------------------
model = Sequential()

# First LSTM layer
model.add(LSTM(units=50, return_sequences=True, input_shape=(x_train.shape[1], len(FEATURES))))
model.add(Dropout(0.2))

# Second LSTM layer
model.add(LSTM(units=50))
model.add(Dropout(0.2))

# Output layer
model.add(Dense(units=1))

# Compile the model
model.compile(optimizer='adam', loss='mean_squared_error')

# Train the model
model.fit(x_train, y_train, epochs=25, batch_size=32)

#------------------------------------------------------------------------------
# Make Predictions
#------------------------------------------------------------------------------
predicted_prices = model.predict(x_test)
scaler_close = scalers["Close"]
predicted_prices = scaler_close.inverse_transform(predicted_prices)
real_prices = scaler_close.inverse_transform(y_test.reshape(-1, 1))

#------------------------------------------------------------------------------
# Plot the Test Predictions
#------------------------------------------------------------------------------
plt.plot(real_prices, color="black", label=f"Actual {COMPANY} Price")
plt.plot(predicted_prices, color="green", label=f"Predicted {COMPANY} Price")
plt.title(f"{COMPANY} Share Price Prediction")
plt.xlabel("Time")
plt.ylabel(f"{COMPANY} Share Price")
plt.legend()
plt.show()

#------------------------------------------------------------------------------
# Candlestick Chart Visualization
#------------------------------------------------------------------------------
def plot_candlestick(data, company, window=2):  # Set window to 2 or higher
    mpf.plot(data, type='candle', mav=window, volume=True, title=f'{company} Candlestick Chart')

# Plot candlestick chart with a moving average of 2 days (or higher)
plot_candlestick(full_data, COMPANY, window=2)

#------------------------------------------------------------------------------
# Boxplot Visualization using Plotly
#------------------------------------------------------------------------------
def plot_boxplot(data, company, window=20):
    # Create boxplot data using rolling windows
    boxplot_data = [
        data['Close'].iloc[i:i + window].dropna().values
        for i in range(0, len(data) - window + 1)
    ]

    # Create a plotly figure for the boxplot
    fig = go.Figure()

    # Add boxplots to the figure
    for i, window_data in enumerate(boxplot_data):
        fig.add_trace(go.Box(
            y=window_data,
            name=f'Window {i + 1}',
            boxpoints='all',  # Show all data points
            jitter=0.3,  # Add jitter to data points for better visualization
            pointpos=-1.8  # Offset data points
        ))

    # Update layout for the figure
    fig.update_layout(
        title=f'{company} Closing Prices Boxplot (Window Size = {window} Days)',
        xaxis_title='Time Windows (Sampled)',
        yaxis_title='Closing Price',
        showlegend=False
    )

    # Show the plot using pyo.plot instead of pyo.iplot
    pyo.plot(fig, filename='boxplot.html')

# Plot boxplot with a rolling window of 20 days
plot_boxplot(full_data, COMPANY, window=20)


#------------------------------------------------------------------------------
# Predict Next Day
#------------------------------------------------------------------------------
real_data = [test_data[FEATURES].iloc[-PREDICTION_DAYS:].values]
real_data = np.array(real_data)
prediction = model.predict(real_data)
prediction = scaler_close.inverse_transform(prediction)
print(f"Prediction for the next day: {prediction[0][0]}")
